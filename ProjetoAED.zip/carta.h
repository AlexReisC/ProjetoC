struct carta{
	int numero;
	char naipe;
};
